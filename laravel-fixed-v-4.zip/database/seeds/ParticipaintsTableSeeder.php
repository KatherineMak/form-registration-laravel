<?php

use Illuminate\Database\Seeder;

class ParticipaintsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //factory(App\Participaint::class, 5)->create();
    }
}
