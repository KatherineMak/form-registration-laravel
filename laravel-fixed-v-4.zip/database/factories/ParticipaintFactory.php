<?php


/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Participaint;
use Faker\Generator as Faker;

$factory->define(Participaint::class, function (Faker $faker) {
    return [
//        'firstname' => $faker->name,
//        'lastname' => $faker->name,
//        'email' => $faker->freeEmail(),
//        'aboutMe' => $faker->paragraph,
    ];
});
