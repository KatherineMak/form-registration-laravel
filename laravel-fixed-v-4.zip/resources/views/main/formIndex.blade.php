@extends('layouts.registration')

@section('content')
    <div  id="form">
    </div>
@endsection
